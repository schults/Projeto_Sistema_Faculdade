/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemafaculdade;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Guilherme
 */
public class Dados {

    final static String arquivoAluno = "D:/Aluno.dat"; // CAMINHO DO ARQUIVO
    final static String arquivoProfessor = "D:/Professor.dat";
    final static String arquivoCoordenador = "D:/Coordenador.dat";
    static FileOutputStream fileos;
    static FileInputStream fis;
    static ObjectOutputStream obj;
    static ObjectInputStream ois;

    /**
     * 
     * @return 
     */
    public static ArrayList<Aluno> lerAlunos() {
        ArrayList<Aluno> alunos = new ArrayList<Aluno>();
        try {
            fis = new FileInputStream(arquivoAluno);
            ois = new ObjectInputStream(fis);

            alunos = (ArrayList) ois.readObject();
            ois.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Dados.class.getName()).log(Level.SEVERE, null, ex);
        } catch (EOFException ex) {
            try {
                fileos = new FileOutputStream(arquivoAluno);
                obj = new ObjectOutputStream(fileos);
                obj.writeObject(new ArrayList<Aluno>()); //ESCREVENDO O OBJETO ALUNO NO ARQUIVO
                obj.flush();
                obj.close();
                fileos.close();
            } catch (FileNotFoundException ex1) {
                Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex1) {
                Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(Dados.class.getName()).log(Level.SEVERE, null, ex);
        }

        return alunos;
    }

    public static ArrayList<Professor> lerProfessores() {
        ArrayList<Professor> professores = new ArrayList<Professor>();
        try {
            fis = new FileInputStream(arquivoProfessor);
            ois = new ObjectInputStream(fis);

            professores = (ArrayList) ois.readObject();
            ois.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Dados.class.getName()).log(Level.SEVERE, null, ex);
        } catch (EOFException ex) {
            try {
                fileos = new FileOutputStream(arquivoProfessor);
                obj = new ObjectOutputStream(fileos);
                obj.writeObject(new ArrayList<Professor>()); //ESCREVENDO O OBJETO ALUNO NO ARQUIVO
                obj.flush();
                obj.close();
                fileos.close();
            } catch (FileNotFoundException ex1) {
                Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex1) {
                Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(Dados.class.getName()).log(Level.SEVERE, null, ex);
        }

        return professores;
    }
    
    public static ArrayList<Coordenador> lerCoordenador(){
        ArrayList<Coordenador> coordenadores = new ArrayList<Coordenador>();
        
        try {
            fis = new FileInputStream(arquivoCoordenador);
            ois = new ObjectInputStream(fis);

            coordenadores = (ArrayList) ois.readObject();
            ois.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Dados.class.getName()).log(Level.SEVERE, null, ex);
        } catch (EOFException ex) {
            try {
                fileos = new FileOutputStream(arquivoCoordenador);
                obj = new ObjectOutputStream(fileos);
                obj.writeObject(new ArrayList<Coordenador>()); //ESCREVENDO O OBJETO ALUNO NO ARQUIVO
                obj.flush();
                obj.close();
                fileos.close();
            } catch (FileNotFoundException ex1) {
                Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex1) {
                Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(Dados.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return coordenadores;
    }

    public static void salvarAluno(Aluno aluno) {

        try {
            ArrayList<Aluno> alunos = Dados.lerAlunos();
            if (aluno != null) {
                alunos.add(aluno);
            }
            fileos = new FileOutputStream(arquivoAluno);
            obj = new ObjectOutputStream(fileos);
            obj.writeObject(alunos); //ESCREVENDO O OBJETO ALUNO NO ARQUIVO
            obj.flush();
            obj.close();
            fileos.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    /**
     * 
     * @param professor 
     */
    public static void salvarProfessor(Professor professor) {

        try {
            ArrayList<Professor> professores = lerProfessores();

            if (professor != null) {
                professores.add(professor);
            }
            fileos = new FileOutputStream(arquivoProfessor);
            obj = new ObjectOutputStream(fileos);
            obj.writeObject(professores); //ESCREVENDO O OBJETO ALUNO NO ARQUIVO
            obj.flush();
            obj.close();
            fileos.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
    public static void salvarCoordenador(Coordenador coordenador){
        try {
            ArrayList<Coordenador> coordenadores = lerCoordenador();

            if (coordenador != null) {
                coordenadores.add(coordenador);
            }
            fileos = new FileOutputStream(arquivoCoordenador);
            obj = new ObjectOutputStream(fileos);
            obj.writeObject(coordenadores); //ESCREVENDO O OBJETO ALUNO NO ARQUIVO
            obj.flush();
            obj.close();
            fileos.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
