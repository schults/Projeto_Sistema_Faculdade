/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemafaculdade;

import java.io.Serializable;

/**
 *
 * @author Guilherme
 */
public class Coordenador extends Professor implements Serializable {

    private static final long serialVersionUID = 5675247519201560124L;

    private String dataInicioCoordenacao;

    /**
     * Método para da Data de Inicio da Coordenação do Coordenador.
     *
     * @return String - Data de Inicio da Coordenação
     */
    public String getDataInicioCoordenacao() {
        return dataInicioCoordenacao;
    }

    /**
     * Método para endereçamento da Data de Inicio da Coordenação do
     * Coordenador.
     *
     * @param dataInicioCoordenacao - Double com a Data de Inicio da Coordenação
     */
    public void setDataInicioCoordenacao(String dataInicioCoordenacao) {
        this.dataInicioCoordenacao = dataInicioCoordenacao;
    }

    /**
     * Método para imprimir os dados da classe Coordenador.
     *
     * @return uma String contendo os dados concatenados
     */
    @Override
    public String toString() {
        return "Coordenador: " + super.toString() + "\nData de Inicio Coordenação: " + dataInicioCoordenacao + "";
    }

    /**
     * Método para verificar se a variavel MATRICULA está recebendo um valor
     * negativo.
     *
     * @param matricula - Int com Matricula
     * @return verdadeiro ou falso
     */
    public static boolean verificaNegativo(int matricula) {
        if (matricula > 0) {
            return true;

        } else {
            return false;
        }
    }
}
