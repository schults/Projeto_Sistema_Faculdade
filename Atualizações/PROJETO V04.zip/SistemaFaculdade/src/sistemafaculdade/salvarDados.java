/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemafaculdade;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author Guilherme
 */
public class salvarDados {
    
    final String caminhoArquivo = "D:\\SalvarDadosAluno.dat"; // CAMINHO DO ARQUIVO
    final String caminhoArquivo2 = "D:\\SalvarDadosProfessor.dat";
    FileOutputStream fileos;
    FileInputStream fis;
    ObjectOutputStream obj;
    ObjectInputStream ois;
             
   
     public void salvarAluno(Aluno aluno) {
       
       try{
             
             fileos = new FileOutputStream(caminhoArquivo);
             obj = new ObjectOutputStream(fileos);
             obj.writeObject(aluno); //ESCREVENDO O OBJETO ALUNO NO ARQUIVO
             obj.flush();
         } catch (FileNotFoundException ex) {
            Logger.getLogger(jfCadastro.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(jfCadastro.class.getName()).log(Level.SEVERE, null, ex);
        }
       
        try {
                 fis = new FileInputStream(caminhoArquivo);
                 ois = new ObjectInputStream(fis);
                 
                 Aluno a = (Aluno) ois.readObject();
                 while(a != null){
                     System.out.println(a.toString());
                     a = (Aluno) ois.readObject();
                 }
                 ois.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(salvarDados.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(salvarDados.class.getName()).log(Level.SEVERE, null, ex);
        }
     }
    
   public void salvarProfessor(Professor professor){
         try{
             
             fileos = new FileOutputStream(caminhoArquivo2);
             obj = new ObjectOutputStream(fileos);
             obj.writeObject(professor); //ESCREVENDO O OBJETO ALUNO NO ARQUIVO
             obj.flush();
         } catch (FileNotFoundException ex) {
            Logger.getLogger(jfCadastro.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(jfCadastro.class.getName()).log(Level.SEVERE, null, ex);
        }
         
             try {
                 fis = new FileInputStream(caminhoArquivo2);
                 ois = new ObjectInputStream(fis);
                 
                 Professor p = (Professor) ois.readObject();
                 while(p != null){
                     System.out.println(p.toString());
                     p = (Professor) ois.readObject();
                 }
                 ois.close();
             } catch (FileNotFoundException ex) {
                 Logger.getLogger(salvarDados.class.getName()).log(Level.SEVERE, null, ex);
             } catch (IOException ex) {
            Logger.getLogger(salvarDados.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(salvarDados.class.getName()).log(Level.SEVERE, null, ex);
        }
         
   }
}