/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemafaculdade;

import java.io.Serializable;

/**
 *
 * @author schul
 */
public class Professor extends Usuario implements Serializable {
    
    private String cpf,
                   endereco,
                   statusProfessor,
                   dataNascimento,
                   login;
            int disciplinasLecionadas;
            
    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }
           

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getStatusProfessor() {
        return statusProfessor;
    }

    public void setStatusProfessor(String statusProfessor) {
        this.statusProfessor = statusProfessor;
    }

    public int getDisciplinasLecionadas() {
        return disciplinasLecionadas;
    }

    public void setDisciplinasLecionadas(int disciplinasLecionadas) {
        this.disciplinasLecionadas = disciplinasLecionadas;
    }
    
     @Override
    public String toString() {
        return "Professor{" + "cpf=" + cpf + ", endereco=" + endereco + ", statusProfessor=" + statusProfessor + ", disciplinasLecionadas=" + disciplinasLecionadas + '}';
    }
           
}
