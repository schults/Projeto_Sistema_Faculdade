/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemafaculdade;

import java.io.Serializable;

/**
 *
 * @author schul
 */
public class Professor extends Usuario implements Serializable {
    
    private static final long serialVersionUID = 30L;

    private String cpf,
                   endereco,
                   dataNascimento,
                   login,
                   status;
            int disciplinasLecionadas;
            
    public String getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }
    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }
           

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public int getDisciplinasLecionadas() {
        return disciplinasLecionadas;
    }

    public void setDisciplinasLecionadas(int disciplinasLecionadas) {
        this.disciplinasLecionadas = disciplinasLecionadas;
    }

     @Override
    public String toString() {
        return "Professor: "+super.toString()+"\nCPF: " + cpf + "\nEndereco: " + endereco + "\nDisciplinas Lecionadas:  " + disciplinasLecionadas + "\n";
    }
           
}
