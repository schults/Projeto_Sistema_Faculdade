/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemafaculdade;


public class ValidarString {
    
    public static boolean isData(String DATA){
        String exemplo = "  /  /    ";
        if(DATA.length() != 10 || DATA.equals(exemplo)){
            
            return false;
        }else{
            return true;
        
        }
    }
    
    /** Método para verificar se a variavel CPF não está recebendo valores iguais.
     *   @param CPF - Int com o numero do CPF
     *   @return verdadeiro ou falso*/
    public static boolean isCPF(String CPF){
        String exemplo = "   .   .   -  ";
        if(CPF.length() != 14 || CPF.equals(exemplo)|| CPF.equals("000.000.000-00") || CPF.equals("111.111.111-11") ||
        CPF.equals("222.222.222-22") || CPF.equals("333.333.333-33") ||
        CPF.equals("444.444.444-44") || CPF.equals("555.555.555-55") ||
        CPF.equals("666.666.666-66") || CPF.equals("777.777.777-77") ||
        CPF.equals("888.888.888-88") || CPF.equals("999.999.999-99")){
            
            return false;
        }else{
            return true;
        }
    }
    
    /** Método para verificar se a variavel TELEFONE não está recebendo um valor nulo.
     *   @param TELEFONE - String com o Telefone
     *   @return verdadeiro ou falso*/
    public static boolean isTelefone(String TELEFONE){
        String exemplo = "(  )      -    ";
        if(TELEFONE.length() != 15 || TELEFONE.equals(exemplo)){
            
            return false;
        }else{
            return true;
        
        }
    }
}
