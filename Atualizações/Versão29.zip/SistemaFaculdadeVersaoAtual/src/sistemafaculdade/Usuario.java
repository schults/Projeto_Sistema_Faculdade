/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemafaculdade;

import java.io.Serializable;


public abstract class Usuario implements Serializable{

    private String telefone = null,
                   email,
                   password,
                   confirmarPassword,
                   status;
             String nome;
    
    /** Método para o determinar o Email do Usuario a ser cadastrado no Sistema.
     *   @return String - Email*/          
    public String getEmail() {
        return email;
    }

    /** Método para endereçamento do Email do Usuario.
     *   @param email - String com Email*/
    public void setEmail(String email) {
        this.email = email;
    }

    /** Método para o determinar uma Senha do Usuario a ser cadastrado no Sistema.
     *   @return String - Senha*/ 
    public String getPassword() {
        return password;
    }

    /** Método para endereçamento da Senha do Usuario.
     *   @param password - String com Senha*/
    public void setPassword(String password) {
        this.password = password;
    }

    /** Método para o confirmar uma Senha de Usuario a ser cadastrado no Sistema..
     *   @return String - Confirmação de Senha*/ 
    public String getConfirmarPassword() {
        return confirmarPassword;
    }

    /** Método para endereçamento da confirmação de Senha do Usuario.
     *   @param confirmarPassword - String com a Confirmação da Senha*/
    public void setConfirmarPassword(String confirmarPassword) {
        this.confirmarPassword = confirmarPassword;
    }
               int matricula;
    
    /** Método para o determinar o Nome do Usuario a ser cadastrado no Sistema..
     *   @return String - Nome*/            
    public String getNome() {
        return nome;
    }
    
    /** Método para endereçamento do Nome do Usuario.
     *   @param nome - String com Nome*/
    public void setNome(String nome) {
        this.nome = nome;
    }

    /** Método para o determinar o Telefone do Usuario a ser cadastrado no Sistema..
     *   @return String - Telefone*/ 
    public String getTelefone() {
        return telefone;
    }

    /** Método para endereçamento do Telefone de um Usuario.
     *   @param telefone - String com Telefone*/
    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    /** Método para o determinar a Matricula do Usuario a ser cadastrado no Sistema..
     *   @return Int - Matricula*/ 
    public int getMatricula() {
        return matricula;
    }

    /** Método para endereçamento da Matricula do Usuario.
     *   @param matricula - Int com a Matricula*/
    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }
    
    /** Método para o Status do Usuario a ser cadastrado no Sistema, se será Ativo ou Inativo.
     *   @return String - Status*/ 
    public String getStatus() {
        return status;
    }

    /** Método para endereçamento do Status do Usuario.
     *   @param status - String com o Status*/
    public void setStatus(String status) {
        this.status = status;
    }
    
   /** Método para verificar se a variavel NOME receberá somente strings.
     *   @param nome - String com Nome
     *   @return verdadeiro ou falso*/
    public abstract boolean verificaString (String nome);
    
    @Override
    /** Método para imprimir os dados da classe Coordenador.
    *   @return uma String contendo os dados concatenados*/
    public String toString() {
        return ""+"" + nome + "\nStatus: " + JFrameTelaCadastroUsuario.status + "\nTelefone: " + telefone + "\nMatricula: " + matricula + "\n";
    }
 }
