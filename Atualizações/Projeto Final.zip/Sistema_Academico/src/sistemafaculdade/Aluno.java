/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemafaculdade;

import java.io.Serializable;
import java.util.regex.Pattern;

/**
 *
 * @author Guilherme
 */
public class Aluno extends Usuario implements Serializable {

    private static final long serialVersionUID = 7079064138496742042L;

    private String cpf,
            endereco,
            dataNascimento,
            login;

    private double nota1,
            nota2;

    /**
     * Método para retorno primeira nota do aluno.
     *
     * @return Double - Primeira Nota
     *
     */
    public double getNota1() {
        return nota1;
    }

    /**
     * Método para endereçamento da Primeira Nota do Aluno.
     *
     * @param nota1 - Double com Primeira Nota
     *
     */
    public void setNota1(double nota1) {
        this.nota1 = nota1;
    }

    /**
     * Método para retorno da segunda nota do aluno.
     *
     * @return Double - Segunda Nota
     *
     */
    public double getNota2() {
        return nota2;
    }

    /**
     * Método para endereçamento da Segunda Nota do Aluno.
     *
     * @param nota2 - Double com Segunda Nota
     *
     */
    public void setNota2(double nota2) {
        this.nota2 = nota2;
    }

    /**
     * Método para retorno do CPF do Aluno.
     *
     * @return String - CPF
     *
     */
    public String getCpf() {
        return cpf;
    }

    /**
     * Método para endereçamento do CPF do Aluno.
     *
     * @param cpf - String com CPF
     *
     */
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    /**
     * Método para retorno do Endereço do Aluno.
     *
     * @return String - Endereço
     *
     */
    public String getEndereco() {
        return endereco;
    }

    /**
     * Método para endereçamento do Endereço do Aluno.
     *
     * @param endereco - String com Endereço
     *
     */
    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    /**
     * Método para retorno da Data de Nascimento do Aluno.
     *
     * @return String - Data de Nascimento
     *
     */
    public String getDataNascimento() {
        return dataNascimento;
    }

    /**
     * Método para endereçamento da Data de Nascimento do Aluno.
     *
     * @param dataNascimento - String com Data de Nascimento
     *
     */
    public void setDataNascimento(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    /**
     * Método para retorno da Matricula do Aluno.
     *
     * @return Int - Matricula
     *
     */
    @Override
    public int getMatricula() {
        return matricula;
    }

    /**
     * Método para endereçamento da Matricula do Aluno.
     *
     * @param matricula - Int com Matricula
     *
     */
    @Override
    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    /**
     * Método para retorno do Login do Aluno para acesso ao sistema.
     *
     * @return String - Login
     *
     */
    public String getLogin() {
        return login;
    }

    /**
     * Método para endereçamento do Login do Aluno para acesso ao sistema.
     *
     * @param login - String com Login
     *
     */
    public void setLogin(String login) {
        this.login = login;
    }

    /**
     * Método para imprimir o nome e o CPF do aluno
     *
     * @return uma String contendo os dados concatenados
     *
     */
    @Override
    public String toString() {
        //return "Aluno: "+super.toString()+"\n" + "CPF = " + cpf + "\nEndereco = " + endereco + "\nData de Nascimento = " + dataNascimento + "\n";
        return getNome() + " - " + getCpf();
    }

    /**
     * Método para imprimir os dados completos do Aluno.
     *
     * @return uma String contendo os dados concatenados
     *
     */
    public String mostrarAluno() {
        return "Aluno: " + super.toString() + "\n" + "CPF: " + cpf + "\nEndereco: " + endereco + "\nData de Nascimento: " + dataNascimento + "\n";
    }

    /**
     * Método para verificar se a variavel NOME receberá somente strings.
     *
     * @param nome - String com Nome
     * @return verdadeiro ou falso
     */
    @Override
    public boolean verificaString(String nome) {

        if (!Pattern.matches("^[A-Za-záàâãéèêíïóôõöúçñÁÀÂÃÉÈÍÏÓÔÕÖÚÇÑ'\\s]+$", nome)) {
            return false;
        } else {
            return true;
        }
    }
    /**
     * Método para verificar se a variavel NOME está ou não em branco.
     *
     * @param nome - String com Nome
     * @return verdadeiro ou falso
     */
    public boolean verificaNomeEmBranco(String nome) {
        if (nome.equals("")) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * Método para verificar se a variavel MATRICULA está recebendo um valor
     * negativo.
     *
     * @param matricula - Int com Matricula
     * @return verdadeiro ou falso
     */
    public static boolean verificaNegativo(int matricula) {
        final int VALOR_0 = 0;
        if (matricula < VALOR_0) {
            return true;

        } else {
            return false;
        }
    } 
}
