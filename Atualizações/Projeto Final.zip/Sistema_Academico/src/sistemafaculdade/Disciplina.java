/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemafaculdade;

import java.io.Serializable;

/**
 *
 * @author Guilherme
 */
public class Disciplina implements Serializable {

    private static final long serialVersionUID = -6930005739603772477L;

    private int codigo;
    private String nome,
            horario,
            institutoResponsavel;

    /**
     * Método para o determinar um Codigo da Disciplina.
     *
     * @return Int - Codigo
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * Método para endereçamento do Código de uma Disciplina.
     *
     * @param codigo - Int com o Codigo
     */
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    /**
     * Método para determinar um nome para a Disciplina.
     *
     * @return String - Nome da Disciplina
     */
    public String getNome() {
        return nome;
    }

    /**
     * Método para endereçamento da Primeira Nota do Aluno.
     *
     * @param nome - String com Nome
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * Método para determinar o Horario que será lecionada a Disciplina.
     *
     * @return String - Horario da Disciplina
     */
    public String getHorario() {
        return horario;
    }

    /**
     * Método para endereçamento do Horario da Disciplina.
     *
     * @param horario - String com Horario
     */
    public void setHorario(String horario) {
        this.horario = horario;
    }

    /**
     * Método para determinar o Instituto Responsavel por lecionar a Disciplina.
     *
     * @return String - Instituto responsavel
     */
    public String getInstitutoResponsavel() {
        return institutoResponsavel;
    }

    /**
     * Método para endereçamento do Instituto Responsavel pela Disciplina.
     *
     * @param institutoResponsavel - String com Instituto Responsavel
     */
    public void setInstitutoResponsavel(String institutoResponsavel) {
        this.institutoResponsavel = institutoResponsavel;
    }

    /**
     * Método para imprimir os dados da classe Coordenador.
     *
     * @return uma String contendo os dados concatenados
     */
    @Override
    public String toString() {
        return "Nome: " + nome + "\nCodigo: " + codigo + "\nHorario: " + horario + "\nInstituto Responsavel: " + institutoResponsavel + "\n";
    }

}
