/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemafaculdade;

import java.io.Serializable;
import java.util.regex.Pattern;

/**
 *
 * @author Guilherme
 */
public class Professor extends Usuario implements Serializable {

    private static final long serialVersionUID = 951734707501876621L;

    private String cpf,
            endereco,
            dataNascimento,
            login,
            status;
    int disciplinasLecionadas;

    /**
     * Método para o determinar a Data de Nascimento do Professor.
     *
     * @return String - Data de Nascimento
     */
    public String getDataNascimento() {
        return dataNascimento;
    }

    /**
     * Método para endereçamento da Data de Nascimento do Professor.
     *
     * @param dataNascimento - String com Data de Nascimento
     */
    public void setDataNascimento(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    /**
     * Método para retorno do Login do Professor para acesso ao sistema.
     *
     * @return String - Login
     */
    public String getLogin() {
        return login;
    }

    /**
     * Método para endereçamento do Login do Professor para acesso ao sistema.
     *
     * @param login - String com Login
     */
    public void setLogin(String login) {
        this.login = login;
    }

    /**
     * Método para retorno do CPF do Professor.
     *
     * @return String - CPF
     */
    public String getCpf() {
        return cpf;
    }

    /**
     * Método para endereçamento do CPF do Professor.
     *
     * @param cpf - Int com CPF
     */
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    /**
     * Método para retorno do Endereço do Professor.
     *
     * @return String - Endereço
     */
    public String getEndereco() {
        return endereco;
    }

    /**
     * Método para endereçamento do Endereço do Professor.
     *
     * @param endereco - String com Endereço
     */
    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    /**
     * Método para determinar a quantidade de Disciplinas Lecionadas pelo
     * Professor.
     *
     * @return Int - Disciplinas Lecionadas
     */
    public int getDisciplinasLecionadas() {
        return disciplinasLecionadas;
    }

    /**
     * Método para endereçamento das Disciplinas Lecionadas.
     *
     * @param disciplinasLecionadas - Int com as Disciplinas Lecionadas
     */
    public void setDisciplinasLecionadas(int disciplinasLecionadas) {
        this.disciplinasLecionadas = disciplinasLecionadas;
    }

    /**
     * Método para imprimir os dados da classe Coordenador.
     *
     * @return uma String contendo os dados concatenados
     */
    @Override
    public String toString() {
        return "Professor: " + super.toString() + "\nCPF: " + cpf + "\nEndereco: " + endereco + "\nDisciplinas Lecionadas:  " + disciplinasLecionadas + "\n";
    }

    /**
     * Método verificar se a variavel NOME receberá somente strings.
     *
     * @param nome - String com Nome
     * @return verdadeiro ou falso
     */
    @Override
    public boolean verificaString(String nome) {

        if (!Pattern.matches("^[A-Za-záàâãéèêíïóôõöúçñÁÀÂÃÉÈÍÏÓÔÕÖÚÇÑ'\\s]+$", nome)) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * Método para verificar se a variavel NOME está recebendo numeros.
     *
     * @param nome - String com Nome
     * @return verdadeiro ou falso
     */
    public boolean verificaStringComNumero(String nome) {

        if (Pattern.matches("^[0-9]*$", nome)) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * Método para verificar se a variavel MATRICULA está recebendo um valor
     * negativo.
     *
     * @param matricula - Int com Matricula
     * @return verdadeiro ou falso
     */
    public static boolean verificaNegativo(int matricula) {
        final int VALOR_0 = 0;
        if (matricula < VALOR_0) {
            return true;

        } else {
            return false;
        }
    }

    /**
     * Método para verificar se a variavel DISCIPLINASLECIONADAS está recebendo
     * um valor maior que 0.
     *
     * @param disciplinasLecionadas - Int com a quantidade de Disciplinas
     * Lecionadas
     * @return verdadeiro ou falso
     */
    public static boolean verificaDisciplinasMaiorQue0(int disciplinasLecionadas) {
        final int VALOR_0 = 0;
        if (disciplinasLecionadas > VALOR_0) {
            return true;

        } else {
            return false;
        }
    }
}
