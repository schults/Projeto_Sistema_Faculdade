/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemafaculdade;

import java.io.Serializable;

/**
 *
 * @author schul
 */
public abstract class Usuario implements Serializable{

    private String telefone = null,
                   email,
                   password,
                   confirmarPassword,
                   status;
             String nome;
    
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getConfirmarPassword() {
        return confirmarPassword;
    }

    public void setConfirmarPassword(String confirmarPassword) {
        this.confirmarPassword = confirmarPassword;
    }
               int matricula;
               
    public String getNome() {
        return nome;
    }
    
    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }
    
    public String getStatus() {
        
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    public abstract boolean verificaString (String nome);
    
  
		
       @Override
    public String toString() {
        return ""+"" + nome + "\nStatus: " + JFrameTelaCadastroUsuario.status + "\nTelefone: " + telefone + "\nMatricula: " + matricula + "\n";
    }
 }
