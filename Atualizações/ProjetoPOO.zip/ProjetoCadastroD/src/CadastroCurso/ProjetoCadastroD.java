/*//******************************************************

//Instituto Federal de São Paulo - Campus Sertãozinho

//Disciplina......: M3LPBD

//Programação de Computadores e Dispositivos Móveis

//Aluno...........: Lúcio Flávio de Paula Couto

//******************************************************

*/
package CadastroCurso;

/**
 *
 * @author Lúcio
 */
public class ProjetoCadastroD {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
