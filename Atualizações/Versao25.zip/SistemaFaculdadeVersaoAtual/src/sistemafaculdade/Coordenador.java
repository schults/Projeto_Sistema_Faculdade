/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemafaculdade;

import java.io.Serializable;

/**
 *
 * @author Guilherme
 */
public class Coordenador extends Professor implements Serializable{
    
    private static final long serialVersionUID = 32L;
    
    private String dataInicioCoordenacao;

    public String getDataInicioCoordenacao() {
        return dataInicioCoordenacao;
    }

    public void setDataInicioCoordenacao(String dataInicioCoordenacao) {
        this.dataInicioCoordenacao = dataInicioCoordenacao;
    }

    @Override
    public String toString() {
        return "Coordenador: "+super.toString()+"\nData de Inicio Coordenação: " + dataInicioCoordenacao + "";
    }
    
     public static boolean verificaNegativo(int matricula){
        if(matricula>0){
            return true;
            
        }else{
            return false;
        }
    }
}
