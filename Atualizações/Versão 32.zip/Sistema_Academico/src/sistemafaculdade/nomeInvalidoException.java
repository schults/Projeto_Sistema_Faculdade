/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemafaculdade;

/**
 *
 * @author Guilherme Schults
 */
public class nomeInvalidoException extends Exception {

    private static final long serialVersionUID = -8103487237540331976L;

    /**
     * Lança uma excessão caso o nome digitado contenha caracteres inválidos.
     * @param msg
     */
    public nomeInvalidoException(String msg){
        super(msg);
    }

    nomeInvalidoException() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
