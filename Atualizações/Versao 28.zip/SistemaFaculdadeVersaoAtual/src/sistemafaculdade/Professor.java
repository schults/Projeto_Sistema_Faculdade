/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemafaculdade;

import java.io.Serializable;
import java.util.regex.Pattern;


public class Professor extends Usuario implements Serializable {
    
    private static final long serialVersionUID = -6720415084179403339L;

    private String cpf,
                   endereco,
                   dataNascimento,
                   login,
                   status;
            int disciplinasLecionadas;
            
    public String getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }
    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }
           

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public int getDisciplinasLecionadas() {
        return disciplinasLecionadas;
    }

    public void setDisciplinasLecionadas(int disciplinasLecionadas) {
        this.disciplinasLecionadas = disciplinasLecionadas;
    }

     @Override
    public String toString() {
        return "Professor: "+super.toString()+"\nCPF: " + cpf + "\nEndereco: " + endereco + "\nDisciplinas Lecionadas:  " + disciplinasLecionadas + "\n";
    }
    
      public boolean verificaString (String nome){
       
        if (!Pattern.matches("^[A-Za-záàâãéèêíïóôõöúçñÁÀÂÃÉÈÍÏÓÔÕÖÚÇÑ'\\s]+$", nome)) {
            return false;
        } else {
            return true;
        }
    }

    public boolean verificaStringComNumero(String nome) {

        if (Pattern.matches("^[0-9]*$", nome)) {
            return false;
        } else {
            return true;
        }
    }
    public static boolean verificaNegativo(int matricula){
        final int VALOR_0 = 0;
        if(matricula<VALOR_0){
            return true;
            
        }else{
            return false;
        }
    }
   
  
     public static boolean verificaDisciplinasMaiorQue0(int disciplinasLecionadas){
        final int VALOR_0 = 0;
        if(disciplinasLecionadas>VALOR_0){
            return true;
            
        }else{
            return false;
        }
    }
}

