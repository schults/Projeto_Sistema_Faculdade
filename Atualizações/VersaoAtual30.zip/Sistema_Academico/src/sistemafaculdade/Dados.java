/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemafaculdade;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Guilherme Ferreira Schults
 * 
 */
public class Dados {

    final static String arquivoAluno = "D:/aluno.dat"; // CAMINHO DO ARQUIVO
    final static String arquivoProfessor = "D:/professor.dat";
    final static String arquivoCoordenador = "D:/coordenador.dat";
    final static String arquivoDisciplina = "D:/disciplina.dat";
    static FileOutputStream fileos;
    static FileInputStream fis;
    static ObjectOutputStream obj;
    static ObjectInputStream ois;
    
    Professor p = new Professor();

    /**
     * Esse método realiza a leitura dos alunos cadastrados no arquivo
     * e retorna os alunos
     * @return alunos
     */
    public static ArrayList<Aluno> lerAlunos() {

        ArrayList<Aluno> alunos = new ArrayList<Aluno>();
        try {
            fis = new FileInputStream(arquivoAluno);
            ois = new ObjectInputStream(fis);

            alunos = (ArrayList) ois.readObject();
            ois.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Dados.class.getName()).log(Level.SEVERE, null, ex);
        } catch (EOFException ex) {
            try {
                fileos = new FileOutputStream(arquivoAluno);
                obj = new ObjectOutputStream(fileos);
                obj.writeObject(new ArrayList<Aluno>()); 
                obj.flush();
                obj.close();
                fileos.close();
            } catch (FileNotFoundException ex1) {
                Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex1) {
                Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(Dados.class.getName()).log(Level.SEVERE, null, ex);
        }

        return alunos;
    }
     /**
     * Esse método realiza a leitura dos professores cadastrados no arquivo
     * e retorna os professores
     * @return professores
     */
    public static ArrayList<Professor> lerProfessores() {
        ArrayList<Professor> professores = new ArrayList<Professor>();
        try {
            fis = new FileInputStream(arquivoProfessor);
            ois = new ObjectInputStream(fis);

            professores = (ArrayList) ois.readObject();
            ois.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Dados.class.getName()).log(Level.SEVERE, null, ex);
        } catch (EOFException ex) {
            try {
                fileos = new FileOutputStream(arquivoProfessor);
                obj = new ObjectOutputStream(fileos);
                obj.writeObject(new ArrayList<Professor>()); 
                obj.flush();
                obj.close();
                fileos.close();
            } catch (FileNotFoundException ex1) {
                Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex1) {
                Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(Dados.class.getName()).log(Level.SEVERE, null, ex);
        }

        return professores;
    }

     /**
     * Esse método realiza a leitura dos coordenadores cadastrados no arquivo
     * e retorna os coordenadores
     * @return coordenadores
     */
    public static ArrayList<Coordenador> lerCoordenador() {
        ArrayList<Coordenador> coordenadores = new ArrayList<Coordenador>();

        try {
            fis = new FileInputStream(arquivoCoordenador);
            ois = new ObjectInputStream(fis);

            coordenadores = (ArrayList) ois.readObject();
            ois.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Dados.class.getName()).log(Level.SEVERE, null, ex);
        } catch (EOFException ex) {
            try {
                fileos = new FileOutputStream(arquivoCoordenador);
                obj = new ObjectOutputStream(fileos);
                obj.writeObject(new ArrayList<Coordenador>()); 
                obj.flush();
                obj.close();
                fileos.close();
            } catch (FileNotFoundException ex1) {
                Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex1) {
                Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(Dados.class.getName()).log(Level.SEVERE, null, ex);
        }

        return coordenadores;
    }
     /**
     * Esse método realiza a leitura das disciplinas cadastradas no arquivo
     * e retorna as disciplinas
     * @return disciplinas
     */
    public static ArrayList<Disciplina> lerDisciplina() {
        ArrayList<Disciplina> disciplinas = new ArrayList<Disciplina>();

        try {
            fis = new FileInputStream(arquivoDisciplina);
            ois = new ObjectInputStream(fis);

            disciplinas = (ArrayList) ois.readObject();
            ois.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Dados.class.getName()).log(Level.SEVERE, null, ex);
        } catch (EOFException ex) {
            try {
                fileos = new FileOutputStream(arquivoDisciplina);
                obj = new ObjectOutputStream(fileos);
                obj.writeObject(new ArrayList<Disciplina>()); 
                obj.flush();
                obj.close();
                fileos.close();
            } catch (FileNotFoundException ex1) {
                Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex1) {
                Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(Dados.class.getName()).log(Level.SEVERE, null, ex);
        }

        return disciplinas;
    }
    /**
     * 
     * Esse método salva as disciplinas no arquivo
     * @param disciplina
     * 
     */
    public static void salvarDisciplina(Disciplina disciplina) {

        try {
            ArrayList<Disciplina> disciplinas = Dados.lerDisciplina();
            if (disciplina != null) {
                disciplinas.add(disciplina);
            }
            fileos = new FileOutputStream(arquivoDisciplina);
            obj = new ObjectOutputStream(fileos);
            obj.writeObject(disciplinas); 
            obj.flush();
            obj.close();
            fileos.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
     /**
     * 
     * Esse método salva os alunos no arquivo
     * @param aluno
     */
    public static void salvarAluno(Aluno aluno) {

        try {
            ArrayList<Aluno> alunos = Dados.lerAlunos();
            if (aluno != null) {
                alunos.add(aluno);
            }
            fileos = new FileOutputStream(arquivoAluno);
            obj = new ObjectOutputStream(fileos);
            obj.writeObject(alunos); 
            obj.flush();
            obj.close();
            fileos.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
   /**
     * 
     * Esse método salva os professores no arquivo
     * @param professor
     */
    public static void salvarProfessor(Professor professor) {

        try {
            ArrayList<Professor> professores = lerProfessores();

            if (professor != null) {
                professores.add(professor);
            }
            fileos = new FileOutputStream(arquivoProfessor);
            obj = new ObjectOutputStream(fileos);
            obj.writeObject(professores); 
            obj.flush();
            obj.close();
            fileos.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    /**
     * 
     * Esse método salva os coordenadores no arquivo
     * @param coordenador
     */
    public static void salvarCoordenador(Coordenador coordenador) {
        try {
            ArrayList<Coordenador> coordenadores = lerCoordenador();

            if (coordenador != null) {
                coordenadores.add(coordenador);
            }
            fileos = new FileOutputStream(arquivoCoordenador);
            obj = new ObjectOutputStream(fileos);
            obj.writeObject(coordenadores);
            obj.flush();
            obj.close();
            fileos.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    /**
     * 
     * Esse método realiza a busca de um professor no arquivo
     * @param login
     * @return professor
     */
    public static Professor procuraProfessor(String login) {
        Professor professor = null;
        for (Professor p : lerProfessores()) {
            if (p.getLogin().equals(login)) {
                professor = p;
            }else{
                 JOptionPane.showMessageDialog(null, "Não foi localizado nenhum professor com o login informado");
            }
        }
        return professor;
    }
    /**
     * 
     * Esse método realiza a busca de um aluno no arquivo
     * @param login
     * @return aluno
     */
    public static Aluno procuraAluno(String login) {
        Aluno aluno = null;
        for (Aluno a : lerAlunos()) {
            if (a.getLogin().equals(login)){
                aluno = a;
            }else{
                JOptionPane.showMessageDialog(null, "Não foi localizado nenhum aluno com o login informado");
            }
        }
        return aluno;
    }
     /**
     * 
     * Esse método realiza a exclusão de um professor do arquivo
     * @param login
     * 
     */
    public static void excluirProfessor(String login) {
        try {
            ArrayList<Professor> professores = lerProfessores();
            int index = -1;

            for (int i = 0; i < professores.size(); i++) {
                if (professores.get(i).getLogin().equals(login)) {
                    index = i;
                }
            }
            if (index > -1) {
                professores.remove(index);
                  JOptionPane.showMessageDialog(null, "Solicitação realizada com sucesso");
                fileos = new FileOutputStream(arquivoProfessor);
                obj = new ObjectOutputStream(fileos);
                obj.writeObject(professores); 
                obj.flush();
                obj.close();
                fileos.close();
            } else {
                JOptionPane.showMessageDialog(null, "Nenhum professor encontrado com o login " + login);
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     /**
     * 
     * Esse método realiza a exclusão de um aluno do arquivo
     * @param login
     * 
     */
    public static void excluirAluno(String login) {
        try {
            ArrayList<Aluno> alunos = lerAlunos();
            int index = -1;

            for (int i = 0; i < alunos.size(); i++) {
                if (alunos.get(i).getLogin().equals(login)) {
                    index = i;
                }
            }
            if (index > -1) {
                
                alunos.remove(index);
                JOptionPane.showMessageDialog(null, "Solicitação realizada com sucesso");
                fileos = new FileOutputStream(arquivoAluno);
                obj = new ObjectOutputStream(fileos);
                obj.writeObject(alunos); 
                obj.flush();
                obj.close();
                fileos.close();
            } else {
                JOptionPane.showMessageDialog(null, "Nenhum aluno encontrado com o login " + login);
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     /**
     * 
     * Esse método realiza a exclusão de um coordenador do arquivo
     * @param login
     * 
     */
    public static void excluirCoordenador(String login) {
        try {
            ArrayList<Coordenador> coordenadores = lerCoordenador();
            int index = -1;

            for (int i = 0; i < coordenadores.size(); i++) {
                if (coordenadores.get(i).getLogin().equals(login)) {
                    index = i;
                }
            }
            if (index > -1) {
                coordenadores.remove(index);
                JOptionPane.showMessageDialog(null, "Solicitação realizada com sucesso");
                fileos = new FileOutputStream(arquivoCoordenador);
                obj = new ObjectOutputStream(fileos);
                obj.writeObject(coordenadores); 
                obj.flush();
                obj.close();
                fileos.close();
            } else {
                JOptionPane.showMessageDialog(null, "Nenhum coordenador encontrado com o login " + login);
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     /**
     * 
     * Esse método realiza a exclusão de uma disciplina do arquivo
     * @param codigo
     * 
     */
    public static void excluirDisciplina(int codigo) {
        try {
            ArrayList<Disciplina> disciplinas = lerDisciplina();
            int index = -1;
            
            for (int i = 0; i < disciplinas.size(); i++) {
                if (disciplinas.get(i).getCodigo() == codigo) {
                    index = i;
                }
            }
            if (index > -1) {
                disciplinas.remove(index);
                JOptionPane.showMessageDialog(null, "Disciplina excluída com sucesso");
                fileos = new FileOutputStream(arquivoDisciplina);
                obj = new ObjectOutputStream(fileos);
                obj.writeObject(disciplinas); 
                obj.flush();
                obj.close();
                fileos.close();
            } else {
                JOptionPane.showMessageDialog(null, "Nenhuma disciplina encontrada com o nome " + codigo);
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(JFrameTelaCadastroUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     /**
     * 
     * Esse método realiza a alteração dos dados cadastrais do professor
     * @param professor
     * 
     */
    public static void editarProfessor(Professor professor) {
        excluirProfessor(professor.getLogin());
        salvarProfessor(professor);
    }   
      /**
     * 
     * Esse método realiza a alteração dos dados cadastrais do aluno
     * @param aluno
     * 
     */
    public static void editarAluno(Aluno aluno) {
        excluirAluno(aluno.getLogin());
        salvarAluno(aluno);
    }
      /**
     * 
     * Esse método realiza a alteração dos dados cadastrais do professor
     * @param coordenador
     * 
     */
    public static void editarCoordenador(Coordenador coordenador) {
        excluirCoordenador(coordenador.getLogin());
        salvarCoordenador(coordenador);
    }
}
