/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemafaculdade;

import java.io.Serializable;

/**
 *
 * @author Guilherme
 */
public class Disciplina implements Serializable {
    
   
     
    private int codigo;
    private String nome,
                   horario,
                   institutoResponsavel;

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public String getInstitutoResponsavel() {
        return institutoResponsavel;
    }

    public void setInstitutoResponsavel(String institutoResponsavel) {
        this.institutoResponsavel = institutoResponsavel;
    }

    @Override
    public String toString() {
        return "Nome: " + nome + "\nCodigo: " + codigo + "\nHorario: " + horario + "\nInstituto Responsavel: " + institutoResponsavel + "\n";
    }

}
